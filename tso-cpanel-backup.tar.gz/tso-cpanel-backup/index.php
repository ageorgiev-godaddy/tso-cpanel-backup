<?php
session_start();

if (isset($_SESSION['authenticated']) && $_SESSION['authenticated'] === true) {
    include('includes/dashboard.php');
} else {
    include('includes/auth.php');
}
?>
